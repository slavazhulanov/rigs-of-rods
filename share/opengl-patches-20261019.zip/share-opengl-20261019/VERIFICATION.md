# Verification record

## Installed game evidence (historical)

Archived installed build `2026.10-dev-4d137bef` ran natively on arm64 with OGRE 1.11.6 and OpenGL3+. The recorded result states Caelum and PagedGeometry were restored and Belgium terrain loaded with full vegetation after the GL3 RGB readback-size fix. Cocoa scaling and OIS mouse coordinates were exercised in native 1x/2x controls with exit code 0. The record reports 152 content files (3,140,661,617 bytes) matching the saved baseline by SHA256; original physics and content archives were not modified.

The archived 413-source validation checkout was `e6c981dc364fdb88ddba77d842487f0a5b6c6a47`, based on Cocoa lifecycle PR #3476 head `6bb679b718f0adb6292521ef33755cc646d39d35`, plus required #3469 platform compile and #3468 resource archive implementation/coverage commits. Content submodule: `34fefdd126784bf87b068fc283f812525d159dd7`. This validates that combined source checkout, not standalone #3476.

## Fresh headless checks for this bundle

The existing OIS #104 CTest build passed 3/3 tests; the existing dependency PR #90 manifest unittest passed 6/6; and the existing PR #3476 input-queue fixture assertions passed. Exact sanitized command outputs are in `verification/`. These were reruns of existing build/test artifacts; they do not imply fresh recompilation.

## Limits

No fresh full-game build was run for this bundle. The archived installed candidate contains work beyond the exported subset, so its runtime evidence does not prove each patch individually. No final-profile performance qualification or stable 60 FPS claim exists. Exhaust visibility, unobstructed water/reflections, all maps and vehicles, and final settings performance remain unverified. The other-port snapshot audited at `85e63739a4edabeef232cf9bfa4362a9bba7127b` currently configures legacy GL and disables GL3+/Caelum; its CI package build demonstrates construction only, not gameplay parity.
