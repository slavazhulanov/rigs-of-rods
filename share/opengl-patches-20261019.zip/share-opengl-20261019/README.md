# OpenGL and Apple Silicon contribution bundle

Prepared 2026-10-19 for author review. No upload or message was sent.

## Contents and applicability

`patches/installed-port/` contains selected patches from the archived installed port, whose source repository baseline is `e85535569102b6251849af574026984e3213b3f4` and final source state is `4d137bef455827b24e7468b30882167386952ae9`. The installed app was native arm64, OGRE 1.11.6, OpenGL3+. These patches depend on separately pinned OGRE 1.11.6, Caelum, PagedGeometry, and OIS sources; they are not a complete port patch and are not directly applicable to the other-port repository without matching dependency baselines.

The OGRE patches cover Apple Silicon utility selection (the selector chooses the scalar/general optimized utility), GL3 RGB readback allocation size, RGBX alpha, GLSL projective texture, terrain material, and Cocoa event/scaling integration. PagedGeometry and Caelum patches cover core-profile shaders, fog, and OGRE include compatibility. Apply only to the exact component versions after reviewing each diff; no universal apply-all script is provided.

`patches/upstream-prs/` contains independent plain diff exports from local RoR/OIS topic worktrees when the local origin base could be resolved. Each remains a separate PR proposal; some branches are stacked. Never apply the files as one sequence without checking ancestry and exact base commits. Patch export itself was not compiled.

## Verification and limits

See `VERIFICATION.md`. Historical installed-game evidence records Belgium terrain loading with vegetation after the readback repair and native Cocoa/OIS scale controls exiting successfully. The installed candidate contained additional work beyond this exported subset, so these outcomes do not prove each exported patch independently. No clean full rebuild of this bundle or final-profile performance qualification was performed. No stable 60 FPS claim is made.

The other-port snapshot audited at `85e63739a4edabeef232cf9bfa4362a9bba7127b` currently selects legacy GL and disables GL3+/Caelum. Its earlier GL3 history is not evidence that the current snapshot uses GL3.

## Licensing

`licenses/` includes available project notices copied verbatim. Patches touch separately licensed upstream components; retain their file-level notices. This bundle makes no blanket license conclusion.

See `PATCH-INDEX.md` for exact local commit provenance and apply ordering, and `upstream-prs/PULL_REQUESTS.json` for public base/head OIDs and URLs. `verification/ois-ctest-20261019.txt` is a sanitized test summary. License files copied from installed dependency source are included where present; missing component notices are not asserted as copied.

See `PATCH-INDEX.md` for per-patch source commits, dependency prerequisite and suggested review order. `upstream-prs/PULL_REQUESTS.json` records public PR bases/heads. `verification/ois-ctest-20261019.txt` records the freshly rerun existing OIS tests.
