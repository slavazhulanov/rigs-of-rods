# Patch index and application guidance

## Installed dependency patch series

The 11 `installed-port/` files come from the archived patch set. Exact pinned components: OGRE `3fc7c8e8e95204894865576d2b45cd4606d6d262`; OIS `fe1d32704133fcc83af2b8dbc4468e4f6d35cc9b`; Caelum `70fcf62f306288c9472cc03a42367c9625c839ea` (archive MD5 `6fa41168cb93d67e7169d0e8e2d73f24`); PagedGeometry `9b4ee07dd7a884c667fc4051523b26b746bbd2c7` (archive MD5 `5514a85cccd4132594d17582f9273047`). OGRE arm64 source also applies the dependency recipe's `scriptlexer.patch`. Archived final app source is `4d137bef455827b24e7468b30882167386952ae9`.

These are excerpts, not a full port. Suggested component order: OGRE architecture/optimized utility; OGRE GL3 readback; OGRE texture/shader/terrain fixes; Caelum; PagedGeometry; OIS Cocoa coordinate mapping; Cocoa event pump. The files are separate component patches and require matching sources above; this is not an automatic cross-repository apply script.

Available standalone notices are copied verbatim in `licenses/`. The pinned Caelum and PagedGeometry upstream source trees did not provide a standalone notice file in the local archive, so no copied notice is claimed for them; their upstream repositories retain their own notices. OIS license notice is included if available locally.

## Installed RoR commits

The six `installed-ror/` files are individual commit-vs-parent diffs: sky/Caelum (`f1bb0a9d`), paged geometry/sky (`a51c8a3b`), audio bindings (`06c1f93a`), GL3 readback integration (`42033cf1`), Cocoa scaling (`64d4734e`), and final integration (`4d137bef`). Full commit and direct-parent OIDs are in `installed-ror/COMMITS.json`. The prerequisite component/dependency baseline is `90053ff0`; final integration overlaps earlier commits. These are not independently applicable to the other-port repo. Review each diff against the exact prerequisite; don't layer all six as one blind sequence.

## Current public proposals

`upstream-prs/PULL_REQUESTS.json` maps all 13 requested public PRs to URL, base/head OIDs, title and draft state. The patch files are `gh pr diff` output at preparation time. The PR base OID is context, not proof that GitHub's returned diff is based directly on that commit (the diff may use the merge base). Treat each patch as a PR review diff; check out the exact PR head and inspect its merge base before applying. Stacked PRs can repeat earlier changes. Public source notices and attribution are retained.
