# Static texture and shader binding audit

**Target:** `aasaasaasss/RigsOfRodsAppleSilicon` commit `85e63739a4edabeef232cf9bfa4362a9bba7127b` (v0.3 baseline). This audit is static and limited to selected production resource paths and their direct C++ setup. It did not build or launch the game, access a GPU, load game libraries, modify source checkouts, or contact the upstream project.

## Confirmed binding defect: SkyX cloud samplers

The path is reached when the selected SkyX `.skx` config sets `<bool>layeredclouds=true` and `<bool>volClouds=false`; `SCfgFileManager.cpp` creates a layer through `getCloudsManager()->add(...)` under that condition. `Terrain.cpp` loads the map’s `skyx_config` when present and otherwise falls back to `SkyXDefault.skx`. The bundled `SkyXDefault.skx` and `SkyXDesert.skx` set layered clouds false and volumetric clouds true, so an existing map config with the two required flags is needed to exercise the path. The volumetric-cloud branch is separate and is outside this patch. The production `SkyX_Clouds.fragment` declares and samples `uClouds`, `uCloudsNormal`, and `uCloudsTile`. Both active GLSL program variants (`SkyX_Clouds_LDR_FP_GLSL` and `SkyX_Clouds_HDR_FP_GLSL`) compile that shader, and both currently have empty `default_params`. `CloudsManager.cpp` creates the pass texture units in this order: `Clouds.png` (unit 0), `CloudsNormal.png` (unit 1), `CloudsTile.png` (unit 2). Its pass update methods set cloud animation/lighting values but never set sampler uniforms. OpenGL initializes sampler uniforms to unit 0; OGRE's legacy GL GLSL link path uploads explicitly supplied sampler parameters, and does not infer sampler units from texture-unit names. Thus all three shader samplers address slot 0 in the baseline: `uClouds` is correct by default, while `uCloudsNormal` and `uCloudsTile` are incorrectly bound. This is a concrete SkyX cloud mapping bug. It does not establish a cause for the reported vehicle-light or all-map darkening symptom.

The separate patch adds the three explicit unit assignments to each GLSL program. A headless regression derives sampler declarations from the actual fragment shader, slot ordering from the production C++ pass creation, and each program's default sampler assignments. Against the unpatched fixture, the check reports the two incorrect sampler bindings in each of LDR and HDR; it passes with the patch. A control fixture that swaps the `Clouds.png` and `CloudsNormal.png` creation order fails against the patched material, showing the test follows the production slot mapping. This is a source contract check; it does not emulate OGRE, compile shaders, or establish visual output.

## Other checked surfaces

- **SkyX Moon:** sampler units are explicitly assigned (`uMoon` 0, `uMoonHalo` 1); no mismatch found in the checked resource path.
- **SkyX volumetric clouds:** `uDensity0` and `uDensity1` have explicit units 0 and 1; no mismatch found in the checked resource path.
- **Vehicle NiceMetal:** shader/program names and sampler declarations/explicit default assignments were reviewed in the selected fork files. No concrete wrong unit mapping was established. The reflection shader uses a 2D specular map rather than the local restore's cube environment, which is a feature difference and not evidence of an incorrect unit binding or of all-map darkening.
- **Flare/light paths:** prior report indicates the compared light creation paths are unchanged; this audit found no shader binding evidence connecting the SkyX defect to the vehicle-light symptom.

These are targeted checks, not an exhaustive audit of every material or content-pack resource. Material inheritance, aliases, and runtime overrides mean unrelated script matches alone were not treated as defects.

## Patch package

`fix-material-sampler-units.patch` is based on the exact target revision above and only changes `resources/SkyX/SkyX.material`. The apply check used a pristine targeted fixture created from that revision's file and passed. `check_skyx_cloud_sampler_bindings.py` can be run against a source tree containing `resources/SkyX/SkyX.material`, `resources/SkyX/SkyX_Clouds.fragment`, and `source/main/gfx/skyx/CloudsManager.cpp`:

```sh
python3 check_skyx_cloud_sampler_bindings.py /path/to/RigsOfRodsAppleSilicon
```

The upstream author has not been contacted by this audit. The patch is prepared for review only.

## Evidence files

- `SHA256-files.txt` records hashes of the upstream source inputs used by the regression, including the configuration reachability check.
- `regression-before.log`, `regression-after.log`, and `regression-order-control.log` record baseline failures, patched pass, and swapped-slot control failure.
- `fix-material-sampler-units.patch` contains the standalone upstream patch.
