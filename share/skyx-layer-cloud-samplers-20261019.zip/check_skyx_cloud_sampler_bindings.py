#!/usr/bin/env python3
"""Check SkyX cloud GLSL samplers against production pass texture-slot order."""
from pathlib import Path
import re
import sys


def block_after(pattern: str, text: str) -> str:
    match = re.search(pattern, text)
    if not match:
        raise AssertionError(f"missing production declaration: {pattern}")
    start = text.find("{", match.end())
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[start + 1:i]
    raise AssertionError(f"unclosed block for: {pattern}")


def check(root: Path) -> list[str]:
    material = (root / "resources/SkyX/SkyX.material").read_text(encoding="latin-1")
    shader_path = root / "resources/SkyX/SkyX_Clouds.fragment"
    shader = shader_path.read_text(encoding="latin-1")
    manager = (root / "source/main/gfx/skyx/CloudsManager.cpp").read_text(encoding="utf-8")

    samplers = set(re.findall(r"\buniform\s+sampler\w+\s+(\w+)\s*;", shader))
    if not samplers:
        raise AssertionError("cloud fragment shader declares no samplers")
    sampler_textures = {
        "uClouds": "Clouds.png",
        "uCloudsNormal": "CloudsNormal.png",
        "uCloudsTile": "CloudsTile.png",
    }
    if samplers != set(sampler_textures):
        raise AssertionError(f"unexpected SkyX cloud sampler set: {sorted(samplers)}")

    # Derive unit indices from actual pass creation order, keyed by production texture names.
    texture_slots = re.findall(r'CloudLayerPass->createTextureUnitState\("([^"]+)"\)', manager)
    if len(texture_slots) != len(set(texture_slots)):
        raise AssertionError(f"cloud pass repeats texture slots: {texture_slots}")
    expected = {}
    for sampler, filename in sampler_textures.items():
        if texture_slots.count(filename) != 1:
            raise AssertionError(f"cloud pass must create exactly one {filename} slot; found {texture_slots.count(filename)}")
        expected[sampler] = texture_slots.index(filename)

    failures = []
    # Both active branches compile the same GLSL shader. OpenGL's default sampler value is unit 0.
    for mode in ("LDR", "HDR"):
        name = f"SkyX_Clouds_{mode}_FP_GLSL"
        program = block_after(rf"fragment_program\s+{name}\s+glsl\b", material)
        source = re.search(r"\bsource\s+(\S+)", program)
        if not source or source.group(1) != shader_path.name:
            raise AssertionError(f"{name} does not compile the inspected cloud shader")
        params = block_after(r"\bdefault_params\b", program)
        bindings = {n: int(i) for n, i in re.findall(r"\bparam_named\s+(\w+)\s+int\s+(\d+)", params)}
        for sampler, unit in expected.items():
            actual = bindings.get(sampler, 0)
            if actual != unit:
                failures.append(f"{mode} {sampler}: expected unit {unit} ({texture_slots[unit]}), got unit {actual}")
    return failures


if len(sys.argv) != 2:
    print("usage: check_skyx_cloud_sampler_bindings.py SOURCE_ROOT", file=sys.stderr)
    sys.exit(2)
try:
    errors = check(Path(sys.argv[1]))
except (AssertionError, OSError) as exc:
    print(f"FAIL: {exc}", file=sys.stderr)
    sys.exit(1)
if errors:
    for error in errors:
        print(f"FAIL: {error}", file=sys.stderr)
    sys.exit(1)
print("PASS: LDR/HDR cloud samplers match their production texture slots")
