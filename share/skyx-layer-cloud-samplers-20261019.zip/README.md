# SkyX cloud sampler unit fix

Target repository: `aasaasaasss/RigsOfRodsAppleSilicon`  
Base revision: `85e63739a4edabeef232cf9bfa4362a9bba7127b`

The patch assigns the cloud shader samplers to the texture slots created by the production cloud pass. The layer-cloud branch is entered only when the loaded SkyX `.skx` configuration has `<bool>layeredclouds=true` and `<bool>volClouds=false`. The map's `skyx_config` selects that config; if the map has no valid custom config, the game uses `SkyXDefault.skx`. The repository's `SkyXDefault.skx` and `SkyXDesert.skx` both set layered clouds false and volumetric clouds true, so they do not exercise this patch. The volumetric-cloud path is separate and unchanged.

## Apply and static check

From the repository root:

```sh
git apply --check fix-material-sampler-units.patch
git apply fix-material-sampler-units.patch
python3 check_skyx_cloud_sampler_bindings.py /path/to/RigsOfRodsAppleSilicon
```

To revert the patch:

```sh
git apply -R fix-material-sampler-units.patch
```

The static regression derives sampler names from the production shader and slot numbers from production texture creation order. It fails against the baseline for the two samplers that default to unit 0 in each shader variant, passes with the patch, and fails a control fixture with a swapped texture creation order.

## Manual verification

Using the project's existing build/run workflow, choose a map whose `skyx_config` points to a `.skx` file with `<bool>layeredclouds=true` and `<bool>volClouds=false`; the bundled default configs do not meet this condition. Compare the layer-cloud appearance before and after the patch from the same camera position and with the same SkyX config/time. Check the project's OGRE log for shader program errors. This change is for SkyX layer-cloud texture mapping; it is not a vehicle-light test. The static regression checks both LDR and HDR shader declarations; a runtime comparison should exercise each lighting mode if the existing workflow makes that convenient.

The static regression does not build or run the game, compile shaders, or validate rendered output. This patch has not been submitted upstream. See `AUDIT.md` for findings, evidence, and scope limits.
